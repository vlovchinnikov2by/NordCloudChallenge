import pandas as pd
import datetime as dt

df = pd.read_csv('btc.csv')

df['dt'] = pd.to_datetime(df['dt'])

# calculate EURO amount
df.loc[:,'market_price_EUR'] = df.loc[:,'market_price'] * 0.87
df.loc[:,'market_cap_EUR'] = df.loc[:,'market_cap'] * 0.87

# set period (last year)
tdlt = dt.timedelta(days=365)
min_dt = df['dt'].max() - tdlt

# filter
df_out = df.loc[df['dt']>min_dt]

# print summary statistics
print('\t\t\t%s\t\t\t%s\t\t%s\n' % (' min','  max', ' average'))
print('%s\t\t%6.2f\t\t\t%6.2f\t\t%6.2f' % ('market_cap_EUR', round(df_out['market_cap_EUR'].min(),2), round(df_out['market_cap_EUR'].max(),2), round(df_out['market_cap_EUR'].mean(),2) ))
print('%s\t%6.2f\t\t\t%6.2f\t%6.2f' % ('market_price_EUR', round(df_out['market_price_EUR'].min(),2), round(df_out['market_price_EUR'].max(),2), round(df_out['market_price_EUR'].mean(),2) ))
print('%s\t\t%6.2f\t\t%6.2f\t%6.2f' % ('bitcoins', round(df_out['total-bitcoins'].min(),2), round(df_out['total-bitcoins'].max(),2), round(df_out['total-bitcoins'].mean(),2) ))
print('%s\t\t%6.2f\t\t%6.2f\t%6.2f' % ('n-payments', round(df_out['n-payments'].min(),2), round(df_out['n-payments'].max(),2), round(df_out['n-payments'].mean(),2) ))

# plot image and new csv output files

import matplotlib.pyplot as plt

plt.plot(df_out['dt'], df_out['market_price_EUR'])
plt.savefig('market_price_EUR_image.png')

df_out[['dt','total-bitcoins','n-payments','market_cap_EUR','market_price_EUR']].to_csv('btc_new_out.csv', index=False)

